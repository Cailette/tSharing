
var join = module.exports = {

    get: function(req, res, next) {
        res.render('invitation');
    },

}