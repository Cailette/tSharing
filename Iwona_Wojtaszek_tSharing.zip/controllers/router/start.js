var start = module.exports = {

    get: function(req, res, next) {
        res.render('start');
    },

}